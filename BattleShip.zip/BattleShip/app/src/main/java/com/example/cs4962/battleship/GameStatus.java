package com.example.cs4962.battleship;

/**
 * Created by Bharath on 10/23/2015.
 */
public enum GameStatus
{
    DEPOLOYMENT_PLAYER1,
    DEPOLOYMENT_PLAYER2,
    PLAYER1_TURN,
    PLAYER2_TURN,
    PLAYER1_WON,
    PLAYER2_WON
}

