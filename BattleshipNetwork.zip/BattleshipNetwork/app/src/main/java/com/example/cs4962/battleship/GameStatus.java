package com.example.cs4962.battleship;

/**
 * Created by Bharath on 10/23/2015.
 */
public enum GameStatus
{
    DONE, PLAYING, WAITING
}

