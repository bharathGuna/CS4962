package com.example.cs4962.battleship;

/**
 * Created by Bharath on 10/21/2015.
 */
public enum ShipType {
    NONE,
    AIRCRAFTCARRIER,
    BATTLESHIP,
    CRUISER,
    DESTROYER;
}


